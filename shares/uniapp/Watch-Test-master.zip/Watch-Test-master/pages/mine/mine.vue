<template>
	<view class="mine animation-fade">
		<!-- 顶部 -->
		<view class="logo flexlogo"  :hover-class="!login ? 'logo-hover' : ''">
			<image class="logo-img" :src="login ? avatarUrl :avatarUrl"></image>
			<view class="logo-title flexlogo">
				<text class="uer-name ">Hi，{{'您未登录'}}</text>
				<text class="go-login navigat-arrow">
				</text>
			</view>
		</view>
		
		<view class="cu-list menu sm-border card-menu margin-top bar-shadown">
			<view class="cu-item" >
				<view class="content">
					<text class="cuIcon-roundadd text-grey"></text>
					<text class="text-grey">我的手机号</text>
				</view>
				<view>15842058333</view>
			</view>
			<view class="cu-item" >
				<view class="content">
					<text class="cuIcon-copy text-grey"></text>
					<text class="text-grey">股票容量</text>
				</view>
				<view>10</view>
			</view>
			<view class="cu-item" >
				<view class="content">
					<text class="cuIcon-info text-grey"></text>
					<text class="text-grey">我的组织</text>
				</view>
			</view>
			
			<view class="cu-item card-item" >
				<view class="content">
					<text class="text-grey">我的股票列表</text>				
				</view>
				
				<view class="cardContent">
					<view class="flex-subl flex">
						 <view class="flex-title">
							  贵州茅台
						 </view>
						  <view class="flex-num flex">
							  <view class="num-text">SH</view>
							  <view class="flex-sub">
								  600519
							  </view>
						  </view>
					</view>
					
					<view class="flex-subr flex" >
						<view class="tagb-content flex">
							<view class="tagb-left flex">
								<text class="tagb">2055.16</text>
							</view>
							<view class="tagb-right flex">
								<text class="tagb">-2.28%</text>
							</view>
						</view>
					</view>	
					
				</view>
				<view class="cardContent">
					<view class="flex-subl flex">
						<view class="flex-title">
							  贵州茅台
						</view>
						<view class="flex-num flex">
							  <view class="num-text">SH</view>
							  <view class="flex-sub">
								  600519
							  </view>
						  </view>
					</view>
					
					<view class="flex-subr flex" >
						<view class="tagb-content flex">
							<view class="tagb-left flex">
								<text class="tagb">2055.16</text>
							</view>
							<view class="tagb-right flex">
								<text class="tagb">-2.28%</text>
							</view>
						</view>
					</view>								
				</view>
			</view>
			
			<view class="msgCon card-item" >
				<view class="content">
					<text class="text-grey">最新消息</text>
				</view>
				<view class="msgCard" >
					<view class="msgTitle">
						2021-07-30 07:00
					</view>
					<view class="msg-cardContent">
						<view class="flex-top flex">
							
							<view class="flex-num flex">
								<view class="num-text">SH</view>
								<view class="flex-title">
									  ST龙韵899
								</view>
							</view>
							<view class="msg-tag">
							  涨停封板
							</view>
					
						</view>
						
						<view class="flex-bottom flex" >
							<view class="tagb-content flex">
								<view class="flex-sub">
									当前
								</view>
								<view class="tagb-left flex">
									<text class="tagb">15.45</text>
								</view>
								<view class="tagb-right flex">
									<text class="tagb">+5.03%</text>
								</view>
							</view>
						</view>								
					</view>
				</view>
			</view>
		</view>
		
	</view>
</template>

<script\
	import {
		getVersion,
	} from '../../service/api/version.js' //版本api
	
	export default {
		data() {
			return {
				versionShow: false, //新版本下载弹出
				version: "",//版本号
				vDownUrl: "",//最新版下载地址
			}
		},
		mounted() {
		},
		methods: {
			getVersionData(){
				var _this =this
				//检查版本 用以升级
				uni.showLoading({
					title: '检测更新...'
				});
				getVersion()
				.then(res => {
					//console.log(res)
					if(_this.version<res.data.version){
						_this.vDownUrl=res.data.url //赋值下载地址
						_this.versionShow=true //弹窗
						uni.showToast({
							position: 'bottom',
							title: "有新版本"
						});
						uni.hideLoading();
					}else{
						uni.hideLoading();
						uni.showToast({
							position: 'bottom',
							title: "无新版本可更新！"
						});
					}
					
				}).catch(err => {
					console.log(err)
					uni.hideLoading();
					uni.showToast({
						position: 'bottom',
						title: "检测失败！"
					});
				})
			},
			isDownload(){
				var _this=this
				_this.loginOutHide()
				//下载更新包 整包下载（浪费 不推荐）
				console.log(_this.vDownUrl)
				var wgtUrl=_this.vDownUrl;
				
				var downToak=plus.downloader.createDownload( wgtUrl, {filename:"_doc/update/"}, function(d,status){  
					if ( status == 200 ) {   
						console.log("下载App成功："+d.filename);  
						plus.nativeUI.showWaiting("安装中...");  
						plus.runtime.install(d.filename,{},function(){  
							plus.nativeUI.closeWaiting();  
							console.log("安装成功！");  
							plus.nativeUI.alert("应用资源更新完成！",function(){  
								plus.runtime.restart();  
							});  
						},function(e){  
							plus.nativeUI.closeWaiting();  
							console.log("安装失败["+e.code+"]："+e.message);  
							plus.nativeUI.alert("安装失败["+e.code+"]："+e.message);  
						});  
					} else {  
						console.log("下载App失败！");  
						plus.nativeUI.alert("下载App失败！");  
					}  
					plus.nativeUI.closeWaiting();  
				})
				downToak.start(); // 开启下载的任务
				var prg = 0;
				var showLoading = plus.nativeUI.showWaiting("正在下载,由于是国外服务器,时间较长请勿关闭...");   //创建一个showWaiting对象 
				downToak.addEventListener("statechanged", function(task, status) {  //给下载任务设置一个监听 并根据状态  做操作
					switch(task.state) {
						case 1:
							showLoading.setTitle("正在下载");
						break;
						case 2:
							showLoading.setTitle("已连接到服务器");
						break;
						case 3:
							prg = parseInt(parseFloat(task.downloadedSize) / parseFloat(task.totalSize) * 100);
							if(prg % 1 == 0) {  // 让百分比 增长
								showLoading.setTitle("　　 已下载" + prg + "%　　 ");
							}
						break;
						case 4:
							plus.nativeUI.closeWaiting();
						break;
				
					}
				
				});

			},
			
		}
	}
</script>

<style lang="scss" scoped>
	@import "../../style/color/color.scss";
	.flex {
		display: flex;
		justify-content: center;
		align-items: center;
	}
	button .cu-tag {
		position: absolute;
		top: 8upx;
		right: 8upx;
	}
	
	@font-face {
		font-family: texticons;
		font-weight: normal;
		font-style: normal;
	}

	.flexlogo{
		display: flex;
	}

	page {
		background-color: #f8f8f8;
	}

	.center {
		flex-direction: column;
	}

	.logo {
		width: 750upx;
		height: 360upx;
		padding: 36upx;
		box-sizing: border-box;
		background: $blackColor-linear;
		flex-direction: row;
		align-items: center;
		
	}

	.logo-hover {
		opacity: 0.8;
	}

	.logo-img {
		width: 150upx;
		height: 150upx;
		border-radius: 150upx;
		background: #000000;
	}

	.logo-title {
		height: 150upx;
		flex: 1;
		align-items: center;
		justify-content: space-between;
		flex-direction: row;
		margin-left: 20upx;
	}

	.uer-name {
		height: 60upx;
		line-height: 60upx;
		font-size: 38upx;
		color: #FFFFFF;
	}

	.go-login.navigat-arrow {
		font-size: 38upx;
		color: #FFFFFF;
	}

	.login-title {
		height: 150upx;
		align-items: self-start;
		justify-content: center;
		flex-direction: column;
		margin-left: 20upx;
	}

	.center-list {
		background-color: #FFFFFF;
		margin-top: 20upx;
		width: 750upx;
		flex-direction: column;
	}

	.center-list-item {
		height: 90upx;
		width: 750upx;
		box-sizing: border-box;
		flex-direction: row;
		padding: 0upx 20upx;
	}

	.border-bottom {
		border-bottom-width: 1upx;
		border-color: #c8c7cc;
		border-bottom-style: solid;
	}

	.list-icon {
		width: 40upx;
		height: 90upx;
		line-height: 90upx;
		font-size: 34upx;
		color: #4cd964;
		text-align: center;
		font-family: texticons;
		margin-right: 20upx;
	}

	.list-text {
		height: 90upx;
		line-height: 90upx;
		font-size: 34upx;
		color: #555;
		flex: 1;
		text-align: left;
	}

	.navigat-arrow {
		height: 90upx;
		width: 40upx;
		line-height: 90upx;
		font-size: 34upx;
		color: #555;
		text-align: right;
		font-family: texticons;
	}
	
	.msgCon {
		padding: 0 15px;
	}
	
	.msgCon .msgCard {
		margin-top: 10px;
	}
	
	.cu-list .card-item {
		margin: 10px auto;
		padding-top: 10px;
		flex-direction: column;
		align-items: flex-start;
	}
	
	.cardContent {
		display: flex;
		justify-content: space-between;
		align-items: center;
		width: 100%;
		height: 100rpx;
		background: #000000;
		margin: 12rpx 4rpx;
	}
	.flex-subl {
		flex-direction: column;
	}
	.flex-subl .flex-title {
		font-size: 32rpx;
		font-weight: bold;
		color: #FFFFFF;
		margin-bottom: 15rpx;
	}
	.flex-subl .num-text {
		background-color: red;
		color: #000000;
		font-size: 28rpx;
		margin-right: 10rpx;
	}
	.flex-subl .flex-sub {
		font-size: 28rpx;
		color: #FFFFFF;
	}
	.flex-subr .tagb-content {
		flex-direction: row;
	}
	.flex-subr .tagb-content .tagb-left {
		color: #FFFFFF;
		font-size: 44rpx;
	}
	.flex-subr .tagb-content .tagb-right {
		color: #FFFFFF;
		font-size: 44rpx;
		background: #1AAD19;
		padding: 10rpx 24rpx;
		margin-left: 16rpx;
	}
	
	
	
	
	
	
	.msg-cardContent {
		display: flex;
		flex-direction: column;
		justify-content: center;
		align-items: flex-start;
		width: 100%;
		height: auto;
		background: #000000;
		margin: 12rpx 4rpx;
		padding: 10rpx 0;
	}
	.msg-tag {
		border: 1rpx solid #555555;
	}
	.flex-top {
		padding: 0 24rpx;
		margin: 20rpx 0;
		width: 100%;
		justify-content: space-between;
	}
	.flex-top .flex-title {
		font-size: 32rpx;
		font-weight: bold;
		color: #FFFFFF;
	}
	.flex-top .num-text {
		background-color: red;
		color: #000000;
		font-size: 28rpx;
		margin-right: 10rpx;
	}
	.flex-top .flex-sub {
		font-size: 28rpx;
		color: #FFFFFF;
	}
	.flex-subr .tagb-content {
		flex-direction: row;
	}
	.flex-subr .tagb-content .tagb-left {
		color: #FFFFFF;
		font-size: 44rpx;
	}
	.flex-subr .tagb-content .tagb-right {
		color: #FFFFFF;
		font-size: 44rpx;
		background: #1AAD19;
		padding: 10rpx 24rpx;
		margin-left: 16rpx;
	}
	.flex-bottom {
		margin-bottom: 10rpx;
		padding: 6rpx 24rpx;
	}
	
	.flex-bottom .tagb-content {
		flex-direction: row;
	}
	.flex-bottom .tagb-content .tagb-left {
		color: #DC143C;
		font-size: 30rpx;
	}
	.flex-bottom .tagb-content .tagb-right {
		color: #DC143C;
		font-size: 30rpx;
		margin-left: 16rpx;
	}
	.flex-bottom .flex-sub {
		font-size: 24rpx;
		color: #FFFFFF;
		margin-right: 18rpx;
	}
</style>