<template>
	<view>
		<view class="mainIndex">
			<home v-if="PageCur=='home'"></home> <!-- 首页 -->
			<ble v-if="PageCur=='ble'"></ble> <!-- 设备蓝牙 -->
			<mine v-if="PageCur=='mine'"></mine> <!-- 我的 -->
		</view>
		
		<view class="cu-bar tabbar bg-white shadow foot mainCD" :style="{zIndex:isTop?'999999':'99'}" >
			<view class="action" :class="PageCur=='home'?'text-black':'text-gray'" @click="NavChange" data-cur="home">
				<view class="cuIcon-homefill"></view> 首页
			</view>
			<view class="action text-gray add-action" @click="NavChange" data-cur="ble">
				<button class="cu-btn cuIcon-add bg-black shadow" @click="NavChange" data-cur="ble"></button>
				添加
			</view>
			<view class="action" :class="PageCur=='mine'?'text-black':'text-gray'" @click="NavChange" data-cur="mine">
				<view class="cuIcon-my"> 
					<view class="cu-tag badge"></view>
				</view>
				我的
			</view>
		</view>
		
	</view>
</template>

<script>
	export default {
		// 在App.vue中的启动方法中，去开启授权
		onLaunch: function() {
		    console.log('App Launch');
		    util.wxAuthorize();
		},
		data() {
			return {
				PageCur: 'home', //切换菜单
				toPageCur: '', //上次切换的菜单
				isTop:false, //底部菜单是否在最顶层
			}
		},
		methods: {
			NavChange: function(e) {
				//底部菜单切换
				this.PageCur = e.currentTarget.dataset.cur
			}
		},
		watch:{
			//监听菜单变化
			'PageCur': function(newVal){
				
				var _this=this
				if(newVal=="ble"){
					//如果切换的蓝牙 就把底部菜单设为最顶层 避免蓝牙处弹出提示不方便切换菜单
					_this.isTop=true
				}else{
					_this.isTop=false
				}
				
				//如果上一次切换的菜单是蓝牙，但是本次切换不是蓝牙，就关闭蓝牙搜索
				if(newVal!="ble" && _this.toPageCur=="ble"){
					uni.stopBluetoothDevicesDiscovery({
					  success(res) {
						console.log("关闭蓝牙搜索"+res)
					  }
					})
				}
				_this.toPageCur=newVal //赋值上一次切换的菜单
			},
		}
	}
</script>

<style lang="scss" scoped>
	@import "../style/color/color.scss";
	
	.mainIndex{
		padding-bottom:128upx;
	}
	.text-black{
		color: $blackColor !important;
	}
	.bg-black{
		background: $blackColor !important;
	}
	
	.cu-bar.tabbar.shadow {
		-webkit-box-shadow: 0 0.5px 36px 0 rgba(43,86,112,.2) !important;
		box-shadow: 0 0.5px 36px 0 rgba(43,86,112,.2) !important;
	}
</style>
