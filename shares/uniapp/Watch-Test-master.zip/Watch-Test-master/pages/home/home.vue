<template>
	<view class="home animation-fade">
		<!-- LOGO -->
		<view class="logo">
			<image src="../../appstatic/watch_icon.png" >
		</view>
		<scroll-view scroll-y class="page">
			<!-- 我的组织列表 -->
			<view class="ring animation-fade" v-for="item in orderList">
				<view class="cu-card article">
					<view class="cu-item bar-shadown">
						<view class="title">
							<view class="text-cut">
								<text class="text-black">{{title}}</text>
							</view>
						</view>
						<view class="content" v-for="item in list">
							<view class="flex-subl flex">
								 <view class="flex-title">
									  贵州茅台
								 </view>
								  <view class="flex-num flex">
									  <view class="num-text">SH</view>
									  <view class="flex-sub">
										  600519
									  </view>
								  </view>
							</view>
							
							<view class="flex-subr flex" >
								<view class="tagb-content flex">
									<view class="tagb-left flex">
										<text class="tagb">2055.16</text>
									</view>
									<view class="tagb-right flex">
										<text class="tagb">-2.28%</text>
									</view>
								</view>
							</view>								
						</view>
					</view>
				</view>
			</view>
			
		</scroll-view>
		
	</view>
</template>

<script>
	import {
		getSwiper,
		getRing,
	} from '../../service/api/home.js'; //首页api
	import {
		getisLogin,
	} from '../../service/api/login.js' //登陆api
	var _this;
	var canvaRing=null;
   
	export default {
		data() {
			return {
				title: "华尔街之麓狼来了", // 我的组织名称
				list:[1,2,3],
				orderList:[1,2]
			}
		},
		mounted() {},
		methods: {}
	}
</script>

<style scoped>
	
.flex {
	display: flex;
	justify-content: center;
	align-items: center;
}
.logo {
	display: flex;
	align-items: center;
	justify-content: center;
	height:480rpx;
}
.logo image {
	width: 200rpx;
	height:200rpx;	
}
.cu-item {
	/* background: lightblue; */
}
.content {
	display: flex;
	justify-content: space-between;
	align-item: center;
	width: 100%;
	height: 140rpx;
	background: #000000;
	margin: 24rpx 4rpx;
}
.flex-subl {
	flex-direction: column;
}
.flex-subl .flex-title {
	font-size: 32rpx;
	font-weight: bold;
	color: #FFFFFF;
	margin-bottom: 15rpx;
}
.flex-subl .num-text {
	background-color: red;
	color: #000000;
	font-size: 28rpx;
	margin-right: 10rpx;
}
.flex-subl .flex-sub {
	font-size: 28rpx;
	color: #FFFFFF;
}
.flex-subr .tagb-content {
	flex-direction: row;
}
.flex-subr .tagb-content .tagb-left {
	color: #FFFFFF;
	font-size: 44rpx;
}
.flex-subr .tagb-content .tagb-right {
	color: #FFFFFF;
	font-size: 44rpx;
	background: #1AAD19;
	padding: 10rpx 24rpx;
	margin-left: 16rpx;
}
</style>