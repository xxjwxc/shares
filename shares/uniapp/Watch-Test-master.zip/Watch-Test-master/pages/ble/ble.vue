<template>
	<view>
		<view class="ble animation-fade">
			<!-- 顶部 -->
			<view style="margin: 20rpx 10rpx;">
				<uni-search-bar :radius="100" @confirm="search" 
				:focus="true" v-model="searchValue" @blur="blur" @input="input" 
				@cancel="cancel" @change="change" @clear="clear"
				placeholder="搜索股票代码(以sh,sz开头)">
				</uni-search-bar>	
			</view>
		</view>
		<view class="pic">
			<image src="../../static/sh601006.gif">
		</view>
		<view class="content">
			<view class="flex-subl flex">
				 <view class="flex-title">
					  贵州茅台
				 </view>
				  <view class="flex-num flex">
					  <view class="num-text">SH</view>
					  <view class="flex-sub">
						  600519
					  </view>
				  </view>
			</view>
			<view class="flex-subr flex" >
				<view class="tagb-content flex">
					<view class="tagb-left flex">
						<text class="tagb">2055.16</text>
					</view>
					<view class="tagb-right flex">
						<text class="tagb">-2.28%</text>
					</view>
				</view>
			</view>					
		</view>	
		<view class="formContent">
			<form @submit="formSubmit" @reset="formReset">
				<view class="uni-form-item">
					<checkbox-group class="checkbox flex">
						<view class="checkboxItem flex">
							<label>
								<checkbox value="checkbox1" /><text>日线金叉提醒</text>
							</label>
							<label>
								<checkbox value="checkbox2" /><text>盘中急涨提醒</text>
							</label>
						</view>
						<view class="checkboxItem flex">
							<label>
								<checkbox value="checkbox3" /><text>盘中急跌提醒</text>
							</label>
							<label>
								<checkbox value="checkbox4" /><text>允许公开到组织</text>
							</label>
						</view>
					</checkbox-group>
				</view>
				<view class="inputItem flex">
					<text class="inputTitle">估价涨跌到：</text>
					<input class="input" placeholder="股票涨跌提醒" type="text"/>
				</view>
				<view class="inputItem flex">
					<text class="inputTitle">涨幅超：</text>
					<input class="input" placeholder="股票涨跌提醒" type="text"/>%
				</view>
				<view class="inputItem flex">
					<text class="inputTitle">跌幅超：</text>
					<input class="input" placeholder="股票涨跌提醒" type="text"/>%
				</view>
				<view class="sendBut">
					<button form-type="submit">提交</button>
				</view>
			</form>
		</view>
	</view>
</template>

<script>
	import {
		getisLogin,
	} from '../../service/api/login.js' //登陆api
	
	export default{
		data(){
			return{
			}
		},
		mounted() {
			var _this=this
			getisLogin() //是否登陆
		},
		methods:{
			formSubmit: function(e) {
				console.log('form发生了submit事件，携带数据为：' + JSON.stringify(e.detail.value))
				var formdata = e.detail.value
				uni.showModal({
					content: '表单数据内容：' + JSON.stringify(formdata),
					showCancel: false
				});
			},
		}
	}
</script>

<style scoped>
	.flex {
		display: flex;
		justify-content: center;
		align-items: center;
	}
	.pic {
		width: 100%;
		height: 410rpx;
		margin-bottom: 24rpx;
	}
	.pic image {
		display: block;
		width: 100%;
		height: 100%;
	}
	.content {
		display: flex;
		justify-content: space-between;
		align-item: center;
		width: 100%;
		height: 120rpx;
		background: #000000;
		padding: 0 24rpx;
		
	}
	.flex-subl {
		flex-direction: column;
	}
	.flex-subl .flex-title {
		font-size: 32rpx;
		font-weight: bold;
		color: #FFFFFF;
		margin-bottom: 15rpx;
	}
	.flex-subl .num-text {
		background-color: red;
		color: #000000;
		font-size: 28rpx;
		margin-right: 10rpx;
	}
	.flex-subl .flex-sub {
		font-size: 28rpx;
		color: #FFFFFF;
	}
	.flex-subr .tagb-content {
		flex-direction: row;
	}
	.flex-subr .tagb-content .tagb-left {
		color: #FFFFFF;
		font-size: 44rpx;
	}
	.flex-subr .tagb-content .tagb-right {
		color: #FFFFFF;
		font-size: 44rpx;
		background: #1AAD19;
		padding: 10rpx 24rpx;
		margin-left: 16rpx;
	}
	
	.checkbox {
		flex-direction: row;
		margin: 60rpx 20rpx;
		justify-content: space-evenly;
	}
	.checkbox .checkboxItem {
		flex-direction: column;
		align-items: flex-start;
	}
	.checkbox .checkboxItem label {
		margin-bottom: 20rpx;
	}
	
	.inputItem {
		flex-direction: row;
	}
	.inputItem .inputTitle {
		padding: 20rpx 0;
		font-size: 30rpx;
	}
	.inputItem .input {
		border: #000000;
		width: 240rpx;
		height: 60rpx;
	}
	.sendBut {
		margin: 40rpx auto;
		width: 80%;
	}
</style>
