package model

import (
	"context"
	"fmt"
	"gorm.io/gorm"
	"time"
)

type _HyTblMgr struct {
	*_BaseMgr
}

// HyTblMgr open func
func HyTblMgr(db *gorm.DB) *_HyTblMgr {
	if db == nil {
		panic(fmt.Errorf("HyTblMgr need init by db"))
	}
	ctx, cancel := context.WithCancel(context.Background())
	return &_HyTblMgr{_BaseMgr: &_BaseMgr{DB: db.Table("hy_tbl"), isRelated: globalIsRelated, ctx: ctx, cancel: cancel, timeout: -1}}
}

// GetTableName get sql table name.获取数据库名字
func (obj *_HyTblMgr) GetTableName() string {
	return "hy_tbl"
}

// Reset 重置gorm会话
func (obj *_HyTblMgr) Reset() *_HyTblMgr {
	obj.New()
	return obj
}

// Get 获取
func (obj *_HyTblMgr) Get() (result HyTbl, err error) {
	err = obj.DB.WithContext(obj.ctx).Model(HyTbl{}).Find(&result).Error

	return
}

// Gets 获取批量结果
func (obj *_HyTblMgr) Gets() (results []*HyTbl, err error) {
	err = obj.DB.WithContext(obj.ctx).Model(HyTbl{}).Find(&results).Error

	return
}

////////////////////////////////// gorm replace /////////////////////////////////
func (obj *_HyTblMgr) Count(count *int64) (tx *gorm.DB) {
	return obj.DB.WithContext(obj.ctx).Model(HyTbl{}).Count(count)
}

//////////////////////////////////////////////////////////////////////////////////

//////////////////////////option case ////////////////////////////////////////////

// WithID id获取
func (obj *_HyTblMgr) WithID(id int) Option {
	return optionFunc(func(o *options) { o.query["id"] = id })
}

// WithName name获取 行业名
func (obj *_HyTblMgr) WithName(name string) Option {
	return optionFunc(func(o *options) { o.query["name"] = name })
}

// WithHyCode hy_code获取 行业代码代码
func (obj *_HyTblMgr) WithHyCode(hyCode string) Option {
	return optionFunc(func(o *options) { o.query["hy_code"] = hyCode })
}

// WithNum num获取 家数
func (obj *_HyTblMgr) WithNum(num int) Option {
	return optionFunc(func(o *options) { o.query["num"] = num })
}

// WithCreatedAt created_at获取 创建时间
func (obj *_HyTblMgr) WithCreatedAt(createdAt time.Time) Option {
	return optionFunc(func(o *options) { o.query["created_at"] = createdAt })
}

// GetByOption 功能选项模式获取
func (obj *_HyTblMgr) GetByOption(opts ...Option) (result HyTbl, err error) {
	options := options{
		query: make(map[string]interface{}, len(opts)),
	}
	for _, o := range opts {
		o.apply(&options)
	}

	err = obj.DB.WithContext(obj.ctx).Model(HyTbl{}).Where(options.query).Find(&result).Error

	return
}

// GetByOptions 批量功能选项模式获取
func (obj *_HyTblMgr) GetByOptions(opts ...Option) (results []*HyTbl, err error) {
	options := options{
		query: make(map[string]interface{}, len(opts)),
	}
	for _, o := range opts {
		o.apply(&options)
	}

	err = obj.DB.WithContext(obj.ctx).Model(HyTbl{}).Where(options.query).Find(&results).Error

	return
}

// SelectPage 分页查询
func (obj *_HyTblMgr) SelectPage(page IPage, opts ...Option) (resultPage IPage, err error) {
	options := options{
		query: make(map[string]interface{}, len(opts)),
	}
	for _, o := range opts {
		o.apply(&options)
	}
	resultPage = page
	results := make([]HyTbl, 0)
	var count int64 // 统计总的记录数
	query := obj.DB.WithContext(obj.ctx).Model(HyTbl{}).Where(options.query)
	query.Count(&count)
	resultPage.SetTotal(count)
	if len(page.GetOrederItemsString()) > 0 {
		query = query.Order(page.GetOrederItemsString())
	}
	err = query.Limit(int(page.GetSize())).Offset(int(page.Offset())).Find(&results).Error

	resultPage.SetRecords(results)
	return
}

//////////////////////////enume case ////////////////////////////////////////////

// GetFromID 通过id获取内容
func (obj *_HyTblMgr) GetFromID(id int) (result HyTbl, err error) {
	err = obj.DB.WithContext(obj.ctx).Model(HyTbl{}).Where("`id` = ?", id).Find(&result).Error

	return
}

// GetBatchFromID 批量查找
func (obj *_HyTblMgr) GetBatchFromID(ids []int) (results []*HyTbl, err error) {
	err = obj.DB.WithContext(obj.ctx).Model(HyTbl{}).Where("`id` IN (?)", ids).Find(&results).Error

	return
}

// GetFromName 通过name获取内容 行业名
func (obj *_HyTblMgr) GetFromName(name string) (result HyTbl, err error) {
	err = obj.DB.WithContext(obj.ctx).Model(HyTbl{}).Where("`name` = ?", name).Find(&result).Error

	return
}

// GetBatchFromName 批量查找 行业名
func (obj *_HyTblMgr) GetBatchFromName(names []string) (results []*HyTbl, err error) {
	err = obj.DB.WithContext(obj.ctx).Model(HyTbl{}).Where("`name` IN (?)", names).Find(&results).Error

	return
}

// GetFromHyCode 通过hy_code获取内容 行业代码代码
func (obj *_HyTblMgr) GetFromHyCode(hyCode string) (result HyTbl, err error) {
	err = obj.DB.WithContext(obj.ctx).Model(HyTbl{}).Where("`hy_code` = ?", hyCode).Find(&result).Error

	return
}

// GetBatchFromHyCode 批量查找 行业代码代码
func (obj *_HyTblMgr) GetBatchFromHyCode(hyCodes []string) (results []*HyTbl, err error) {
	err = obj.DB.WithContext(obj.ctx).Model(HyTbl{}).Where("`hy_code` IN (?)", hyCodes).Find(&results).Error

	return
}

// GetFromNum 通过num获取内容 家数
func (obj *_HyTblMgr) GetFromNum(num int) (results []*HyTbl, err error) {
	err = obj.DB.WithContext(obj.ctx).Model(HyTbl{}).Where("`num` = ?", num).Find(&results).Error

	return
}

// GetBatchFromNum 批量查找 家数
func (obj *_HyTblMgr) GetBatchFromNum(nums []int) (results []*HyTbl, err error) {
	err = obj.DB.WithContext(obj.ctx).Model(HyTbl{}).Where("`num` IN (?)", nums).Find(&results).Error

	return
}

// GetFromCreatedAt 通过created_at获取内容 创建时间
func (obj *_HyTblMgr) GetFromCreatedAt(createdAt time.Time) (results []*HyTbl, err error) {
	err = obj.DB.WithContext(obj.ctx).Model(HyTbl{}).Where("`created_at` = ?", createdAt).Find(&results).Error

	return
}

// GetBatchFromCreatedAt 批量查找 创建时间
func (obj *_HyTblMgr) GetBatchFromCreatedAt(createdAts []time.Time) (results []*HyTbl, err error) {
	err = obj.DB.WithContext(obj.ctx).Model(HyTbl{}).Where("`created_at` IN (?)", createdAts).Find(&results).Error

	return
}

//////////////////////////primary index case ////////////////////////////////////////////

// FetchByPrimaryKey primary or index 获取唯一内容
func (obj *_HyTblMgr) FetchByPrimaryKey(id int) (result HyTbl, err error) {
	err = obj.DB.WithContext(obj.ctx).Model(HyTbl{}).Where("`id` = ?", id).Find(&result).Error

	return
}

// FetchUniqueByName primary or index 获取唯一内容
func (obj *_HyTblMgr) FetchUniqueByName(name string) (result HyTbl, err error) {
	err = obj.DB.WithContext(obj.ctx).Model(HyTbl{}).Where("`name` = ?", name).Find(&result).Error

	return
}

// FetchUniqueByHyCode primary or index 获取唯一内容
func (obj *_HyTblMgr) FetchUniqueByHyCode(hyCode string) (result HyTbl, err error) {
	err = obj.DB.WithContext(obj.ctx).Model(HyTbl{}).Where("`hy_code` = ?", hyCode).Find(&result).Error

	return
}
