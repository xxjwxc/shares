package model

import (
	"context"
	"fmt"
	"gorm.io/gorm"
	"time"
)

type _HyGroupDailyTblMgr struct {
	*_BaseMgr
}

// HyGroupDailyTblMgr open func
func HyGroupDailyTblMgr(db *gorm.DB) *_HyGroupDailyTblMgr {
	if db == nil {
		panic(fmt.Errorf("HyGroupDailyTblMgr need init by db"))
	}
	ctx, cancel := context.WithCancel(context.Background())
	return &_HyGroupDailyTblMgr{_BaseMgr: &_BaseMgr{DB: db.Table("hy_group_daily_tbl"), isRelated: globalIsRelated, ctx: ctx, cancel: cancel, timeout: -1}}
}

// GetTableName get sql table name.获取数据库名字
func (obj *_HyGroupDailyTblMgr) GetTableName() string {
	return "hy_group_daily_tbl"
}

// Reset 重置gorm会话
func (obj *_HyGroupDailyTblMgr) Reset() *_HyGroupDailyTblMgr {
	obj.New()
	return obj
}

// Get 获取
func (obj *_HyGroupDailyTblMgr) Get() (result HyGroupDailyTbl, err error) {
	err = obj.DB.WithContext(obj.ctx).Model(HyGroupDailyTbl{}).Find(&result).Error

	return
}

// Gets 获取批量结果
func (obj *_HyGroupDailyTblMgr) Gets() (results []*HyGroupDailyTbl, err error) {
	err = obj.DB.WithContext(obj.ctx).Model(HyGroupDailyTbl{}).Find(&results).Error

	return
}

////////////////////////////////// gorm replace /////////////////////////////////
func (obj *_HyGroupDailyTblMgr) Count(count *int64) (tx *gorm.DB) {
	return obj.DB.WithContext(obj.ctx).Model(HyGroupDailyTbl{}).Count(count)
}

//////////////////////////////////////////////////////////////////////////////////

//////////////////////////option case ////////////////////////////////////////////

// WithID id获取
func (obj *_HyGroupDailyTblMgr) WithID(id int) Option {
	return optionFunc(func(o *options) { o.query["id"] = id })
}

// WithHyCode hy_code获取 行业代码
func (obj *_HyGroupDailyTblMgr) WithHyCode(hyCode string) Option {
	return optionFunc(func(o *options) { o.query["hy_code"] = hyCode })
}

// WithHyName hy_name获取 行业名
func (obj *_HyGroupDailyTblMgr) WithHyName(hyName string) Option {
	return optionFunc(func(o *options) { o.query["hy_name"] = hyName })
}

// WithDay0 day0获取 当日0点时间戳
func (obj *_HyGroupDailyTblMgr) WithDay0(day0 int64) Option {
	return optionFunc(func(o *options) { o.query["day0"] = day0 })
}

// WithDayStr day_str获取 入池时间
func (obj *_HyGroupDailyTblMgr) WithDayStr(dayStr string) Option {
	return optionFunc(func(o *options) { o.query["day_str"] = dayStr })
}

// WithPrice price获取 当前净流入(万元)
func (obj *_HyGroupDailyTblMgr) WithPrice(price float64) Option {
	return optionFunc(func(o *options) { o.query["price"] = price })
}

// WithCreatedAt created_at获取 创建时间
func (obj *_HyGroupDailyTblMgr) WithCreatedAt(createdAt time.Time) Option {
	return optionFunc(func(o *options) { o.query["created_at"] = createdAt })
}

// GetByOption 功能选项模式获取
func (obj *_HyGroupDailyTblMgr) GetByOption(opts ...Option) (result HyGroupDailyTbl, err error) {
	options := options{
		query: make(map[string]interface{}, len(opts)),
	}
	for _, o := range opts {
		o.apply(&options)
	}

	err = obj.DB.WithContext(obj.ctx).Model(HyGroupDailyTbl{}).Where(options.query).Find(&result).Error

	return
}

// GetByOptions 批量功能选项模式获取
func (obj *_HyGroupDailyTblMgr) GetByOptions(opts ...Option) (results []*HyGroupDailyTbl, err error) {
	options := options{
		query: make(map[string]interface{}, len(opts)),
	}
	for _, o := range opts {
		o.apply(&options)
	}

	err = obj.DB.WithContext(obj.ctx).Model(HyGroupDailyTbl{}).Where(options.query).Find(&results).Error

	return
}

// SelectPage 分页查询
func (obj *_HyGroupDailyTblMgr) SelectPage(page IPage, opts ...Option) (resultPage IPage, err error) {
	options := options{
		query: make(map[string]interface{}, len(opts)),
	}
	for _, o := range opts {
		o.apply(&options)
	}
	resultPage = page
	results := make([]HyGroupDailyTbl, 0)
	var count int64 // 统计总的记录数
	query := obj.DB.WithContext(obj.ctx).Model(HyGroupDailyTbl{}).Where(options.query)
	query.Count(&count)
	resultPage.SetTotal(count)
	if len(page.GetOrederItemsString()) > 0 {
		query = query.Order(page.GetOrederItemsString())
	}
	err = query.Limit(int(page.GetSize())).Offset(int(page.Offset())).Find(&results).Error

	resultPage.SetRecords(results)
	return
}

//////////////////////////enume case ////////////////////////////////////////////

// GetFromID 通过id获取内容
func (obj *_HyGroupDailyTblMgr) GetFromID(id int) (result HyGroupDailyTbl, err error) {
	err = obj.DB.WithContext(obj.ctx).Model(HyGroupDailyTbl{}).Where("`id` = ?", id).Find(&result).Error

	return
}

// GetBatchFromID 批量查找
func (obj *_HyGroupDailyTblMgr) GetBatchFromID(ids []int) (results []*HyGroupDailyTbl, err error) {
	err = obj.DB.WithContext(obj.ctx).Model(HyGroupDailyTbl{}).Where("`id` IN (?)", ids).Find(&results).Error

	return
}

// GetFromHyCode 通过hy_code获取内容 行业代码
func (obj *_HyGroupDailyTblMgr) GetFromHyCode(hyCode string) (results []*HyGroupDailyTbl, err error) {
	err = obj.DB.WithContext(obj.ctx).Model(HyGroupDailyTbl{}).Where("`hy_code` = ?", hyCode).Find(&results).Error

	return
}

// GetBatchFromHyCode 批量查找 行业代码
func (obj *_HyGroupDailyTblMgr) GetBatchFromHyCode(hyCodes []string) (results []*HyGroupDailyTbl, err error) {
	err = obj.DB.WithContext(obj.ctx).Model(HyGroupDailyTbl{}).Where("`hy_code` IN (?)", hyCodes).Find(&results).Error

	return
}

// GetFromHyName 通过hy_name获取内容 行业名
func (obj *_HyGroupDailyTblMgr) GetFromHyName(hyName string) (results []*HyGroupDailyTbl, err error) {
	err = obj.DB.WithContext(obj.ctx).Model(HyGroupDailyTbl{}).Where("`hy_name` = ?", hyName).Find(&results).Error

	return
}

// GetBatchFromHyName 批量查找 行业名
func (obj *_HyGroupDailyTblMgr) GetBatchFromHyName(hyNames []string) (results []*HyGroupDailyTbl, err error) {
	err = obj.DB.WithContext(obj.ctx).Model(HyGroupDailyTbl{}).Where("`hy_name` IN (?)", hyNames).Find(&results).Error

	return
}

// GetFromDay0 通过day0获取内容 当日0点时间戳
func (obj *_HyGroupDailyTblMgr) GetFromDay0(day0 int64) (results []*HyGroupDailyTbl, err error) {
	err = obj.DB.WithContext(obj.ctx).Model(HyGroupDailyTbl{}).Where("`day0` = ?", day0).Find(&results).Error

	return
}

// GetBatchFromDay0 批量查找 当日0点时间戳
func (obj *_HyGroupDailyTblMgr) GetBatchFromDay0(day0s []int64) (results []*HyGroupDailyTbl, err error) {
	err = obj.DB.WithContext(obj.ctx).Model(HyGroupDailyTbl{}).Where("`day0` IN (?)", day0s).Find(&results).Error

	return
}

// GetFromDayStr 通过day_str获取内容 入池时间
func (obj *_HyGroupDailyTblMgr) GetFromDayStr(dayStr string) (results []*HyGroupDailyTbl, err error) {
	err = obj.DB.WithContext(obj.ctx).Model(HyGroupDailyTbl{}).Where("`day_str` = ?", dayStr).Find(&results).Error

	return
}

// GetBatchFromDayStr 批量查找 入池时间
func (obj *_HyGroupDailyTblMgr) GetBatchFromDayStr(dayStrs []string) (results []*HyGroupDailyTbl, err error) {
	err = obj.DB.WithContext(obj.ctx).Model(HyGroupDailyTbl{}).Where("`day_str` IN (?)", dayStrs).Find(&results).Error

	return
}

// GetFromPrice 通过price获取内容 当前净流入(万元)
func (obj *_HyGroupDailyTblMgr) GetFromPrice(price float64) (results []*HyGroupDailyTbl, err error) {
	err = obj.DB.WithContext(obj.ctx).Model(HyGroupDailyTbl{}).Where("`price` = ?", price).Find(&results).Error

	return
}

// GetBatchFromPrice 批量查找 当前净流入(万元)
func (obj *_HyGroupDailyTblMgr) GetBatchFromPrice(prices []float64) (results []*HyGroupDailyTbl, err error) {
	err = obj.DB.WithContext(obj.ctx).Model(HyGroupDailyTbl{}).Where("`price` IN (?)", prices).Find(&results).Error

	return
}

// GetFromCreatedAt 通过created_at获取内容 创建时间
func (obj *_HyGroupDailyTblMgr) GetFromCreatedAt(createdAt time.Time) (results []*HyGroupDailyTbl, err error) {
	err = obj.DB.WithContext(obj.ctx).Model(HyGroupDailyTbl{}).Where("`created_at` = ?", createdAt).Find(&results).Error

	return
}

// GetBatchFromCreatedAt 批量查找 创建时间
func (obj *_HyGroupDailyTblMgr) GetBatchFromCreatedAt(createdAts []time.Time) (results []*HyGroupDailyTbl, err error) {
	err = obj.DB.WithContext(obj.ctx).Model(HyGroupDailyTbl{}).Where("`created_at` IN (?)", createdAts).Find(&results).Error

	return
}

//////////////////////////primary index case ////////////////////////////////////////////

// FetchByPrimaryKey primary or index 获取唯一内容
func (obj *_HyGroupDailyTblMgr) FetchByPrimaryKey(id int) (result HyGroupDailyTbl, err error) {
	err = obj.DB.WithContext(obj.ctx).Model(HyGroupDailyTbl{}).Where("`id` = ?", id).Find(&result).Error

	return
}

// FetchUniqueIndexByCode primary or index 获取唯一内容
func (obj *_HyGroupDailyTblMgr) FetchUniqueIndexByCode(hyCode string, day0 int64) (result HyGroupDailyTbl, err error) {
	err = obj.DB.WithContext(obj.ctx).Model(HyGroupDailyTbl{}).Where("`hy_code` = ? AND `day0` = ?", hyCode, day0).Find(&result).Error

	return
}
