package model

import (
	"context"
	"fmt"
	"gorm.io/gorm"
)

type _WatchViewMgr struct {
	*_BaseMgr
}

// WatchViewMgr open func
func WatchViewMgr(db *gorm.DB) *_WatchViewMgr {
	if db == nil {
		panic(fmt.Errorf("WatchViewMgr need init by db"))
	}
	ctx, cancel := context.WithCancel(context.Background())
	return &_WatchViewMgr{_BaseMgr: &_BaseMgr{DB: db.Table("watch_view"), isRelated: globalIsRelated, ctx: ctx, cancel: cancel, timeout: -1}}
}

// GetTableName get sql table name.获取数据库名字
func (obj *_WatchViewMgr) GetTableName() string {
	return "watch_view"
}

// Reset 重置gorm会话
func (obj *_WatchViewMgr) Reset() *_WatchViewMgr {
	obj.New()
	return obj
}

// Get 获取
func (obj *_WatchViewMgr) Get() (result WatchView, err error) {
	err = obj.DB.WithContext(obj.ctx).Model(WatchView{}).Find(&result).Error

	return
}

// Gets 获取批量结果
func (obj *_WatchViewMgr) Gets() (results []*WatchView, err error) {
	err = obj.DB.WithContext(obj.ctx).Model(WatchView{}).Find(&results).Error

	return
}

////////////////////////////////// gorm replace /////////////////////////////////
func (obj *_WatchViewMgr) Count(count *int64) (tx *gorm.DB) {
	return obj.DB.WithContext(obj.ctx).Model(WatchView{}).Count(count)
}

//////////////////////////////////////////////////////////////////////////////////

//////////////////////////option case ////////////////////////////////////////////

// WithID id获取
func (obj *_WatchViewMgr) WithID(id int) Option {
	return optionFunc(func(o *options) { o.query["id"] = id })
}

// WithCode code获取 股票代码
func (obj *_WatchViewMgr) WithCode(code string) Option {
	return optionFunc(func(o *options) { o.query["code"] = code })
}

// WithName name获取 股票名字
func (obj *_WatchViewMgr) WithName(name string) Option {
	return optionFunc(func(o *options) { o.query["name"] = name })
}

// WithPrice price获取 当前价格
func (obj *_WatchViewMgr) WithPrice(price float64) Option {
	return optionFunc(func(o *options) { o.query["price"] = price })
}

// WithPercent percent获取 百分比
func (obj *_WatchViewMgr) WithPercent(percent float64) Option {
	return optionFunc(func(o *options) { o.query["percent"] = percent })
}

// WithGroupName group_name获取 分组名
func (obj *_WatchViewMgr) WithGroupName(groupName string) Option {
	return optionFunc(func(o *options) { o.query["group_name"] = groupName })
}

// WithUserName user_name获取 推荐人
func (obj *_WatchViewMgr) WithUserName(userName string) Option {
	return optionFunc(func(o *options) { o.query["user_name"] = userName })
}

// WithTp tp获取
func (obj *_WatchViewMgr) WithTp(tp string) Option {
	return optionFunc(func(o *options) { o.query["tp"] = tp })
}

// GetByOption 功能选项模式获取
func (obj *_WatchViewMgr) GetByOption(opts ...Option) (result WatchView, err error) {
	options := options{
		query: make(map[string]interface{}, len(opts)),
	}
	for _, o := range opts {
		o.apply(&options)
	}

	err = obj.DB.WithContext(obj.ctx).Model(WatchView{}).Where(options.query).Find(&result).Error

	return
}

// GetByOptions 批量功能选项模式获取
func (obj *_WatchViewMgr) GetByOptions(opts ...Option) (results []*WatchView, err error) {
	options := options{
		query: make(map[string]interface{}, len(opts)),
	}
	for _, o := range opts {
		o.apply(&options)
	}

	err = obj.DB.WithContext(obj.ctx).Model(WatchView{}).Where(options.query).Find(&results).Error

	return
}

// SelectPage 分页查询
func (obj *_WatchViewMgr) SelectPage(page IPage, opts ...Option) (resultPage IPage, err error) {
	options := options{
		query: make(map[string]interface{}, len(opts)),
	}
	for _, o := range opts {
		o.apply(&options)
	}
	resultPage = page
	results := make([]WatchView, 0)
	var count int64 // 统计总的记录数
	query := obj.DB.WithContext(obj.ctx).Model(WatchView{}).Where(options.query)
	query.Count(&count)
	resultPage.SetTotal(count)
	if len(page.GetOrederItemsString()) > 0 {
		query = query.Order(page.GetOrederItemsString())
	}
	err = query.Limit(int(page.GetSize())).Offset(int(page.Offset())).Find(&results).Error

	resultPage.SetRecords(results)
	return
}

//////////////////////////enume case ////////////////////////////////////////////

// GetFromID 通过id获取内容
func (obj *_WatchViewMgr) GetFromID(id int) (results []*WatchView, err error) {
	err = obj.DB.WithContext(obj.ctx).Model(WatchView{}).Where("`id` = ?", id).Find(&results).Error

	return
}

// GetBatchFromID 批量查找
func (obj *_WatchViewMgr) GetBatchFromID(ids []int) (results []*WatchView, err error) {
	err = obj.DB.WithContext(obj.ctx).Model(WatchView{}).Where("`id` IN (?)", ids).Find(&results).Error

	return
}

// GetFromCode 通过code获取内容 股票代码
func (obj *_WatchViewMgr) GetFromCode(code string) (results []*WatchView, err error) {
	err = obj.DB.WithContext(obj.ctx).Model(WatchView{}).Where("`code` = ?", code).Find(&results).Error

	return
}

// GetBatchFromCode 批量查找 股票代码
func (obj *_WatchViewMgr) GetBatchFromCode(codes []string) (results []*WatchView, err error) {
	err = obj.DB.WithContext(obj.ctx).Model(WatchView{}).Where("`code` IN (?)", codes).Find(&results).Error

	return
}

// GetFromName 通过name获取内容 股票名字
func (obj *_WatchViewMgr) GetFromName(name string) (results []*WatchView, err error) {
	err = obj.DB.WithContext(obj.ctx).Model(WatchView{}).Where("`name` = ?", name).Find(&results).Error

	return
}

// GetBatchFromName 批量查找 股票名字
func (obj *_WatchViewMgr) GetBatchFromName(names []string) (results []*WatchView, err error) {
	err = obj.DB.WithContext(obj.ctx).Model(WatchView{}).Where("`name` IN (?)", names).Find(&results).Error

	return
}

// GetFromPrice 通过price获取内容 当前价格
func (obj *_WatchViewMgr) GetFromPrice(price float64) (results []*WatchView, err error) {
	err = obj.DB.WithContext(obj.ctx).Model(WatchView{}).Where("`price` = ?", price).Find(&results).Error

	return
}

// GetBatchFromPrice 批量查找 当前价格
func (obj *_WatchViewMgr) GetBatchFromPrice(prices []float64) (results []*WatchView, err error) {
	err = obj.DB.WithContext(obj.ctx).Model(WatchView{}).Where("`price` IN (?)", prices).Find(&results).Error

	return
}

// GetFromPercent 通过percent获取内容 百分比
func (obj *_WatchViewMgr) GetFromPercent(percent float64) (results []*WatchView, err error) {
	err = obj.DB.WithContext(obj.ctx).Model(WatchView{}).Where("`percent` = ?", percent).Find(&results).Error

	return
}

// GetBatchFromPercent 批量查找 百分比
func (obj *_WatchViewMgr) GetBatchFromPercent(percents []float64) (results []*WatchView, err error) {
	err = obj.DB.WithContext(obj.ctx).Model(WatchView{}).Where("`percent` IN (?)", percents).Find(&results).Error

	return
}

// GetFromGroupName 通过group_name获取内容 分组名
func (obj *_WatchViewMgr) GetFromGroupName(groupName string) (results []*WatchView, err error) {
	err = obj.DB.WithContext(obj.ctx).Model(WatchView{}).Where("`group_name` = ?", groupName).Find(&results).Error

	return
}

// GetBatchFromGroupName 批量查找 分组名
func (obj *_WatchViewMgr) GetBatchFromGroupName(groupNames []string) (results []*WatchView, err error) {
	err = obj.DB.WithContext(obj.ctx).Model(WatchView{}).Where("`group_name` IN (?)", groupNames).Find(&results).Error

	return
}

// GetFromUserName 通过user_name获取内容 推荐人
func (obj *_WatchViewMgr) GetFromUserName(userName string) (results []*WatchView, err error) {
	err = obj.DB.WithContext(obj.ctx).Model(WatchView{}).Where("`user_name` = ?", userName).Find(&results).Error

	return
}

// GetBatchFromUserName 批量查找 推荐人
func (obj *_WatchViewMgr) GetBatchFromUserName(userNames []string) (results []*WatchView, err error) {
	err = obj.DB.WithContext(obj.ctx).Model(WatchView{}).Where("`user_name` IN (?)", userNames).Find(&results).Error

	return
}

// GetFromTp 通过tp获取内容
func (obj *_WatchViewMgr) GetFromTp(tp string) (results []*WatchView, err error) {
	err = obj.DB.WithContext(obj.ctx).Model(WatchView{}).Where("`tp` = ?", tp).Find(&results).Error

	return
}

// GetBatchFromTp 批量查找
func (obj *_WatchViewMgr) GetBatchFromTp(tps []string) (results []*WatchView, err error) {
	err = obj.DB.WithContext(obj.ctx).Model(WatchView{}).Where("`tp` IN (?)", tps).Find(&results).Error

	return
}

//////////////////////////primary index case ////////////////////////////////////////////
