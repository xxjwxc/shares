package model

import (
	"context"
	"fmt"
	"gorm.io/datatypes"
	"gorm.io/gorm"
	"time"
)

type _MyselfViewMgr struct {
	*_BaseMgr
}

// MyselfViewMgr open func
func MyselfViewMgr(db *gorm.DB) *_MyselfViewMgr {
	if db == nil {
		panic(fmt.Errorf("MyselfViewMgr need init by db"))
	}
	ctx, cancel := context.WithCancel(context.Background())
	return &_MyselfViewMgr{_BaseMgr: &_BaseMgr{DB: db.Table("myself_view"), isRelated: globalIsRelated, ctx: ctx, cancel: cancel, timeout: -1}}
}

// GetTableName get sql table name.获取数据库名字
func (obj *_MyselfViewMgr) GetTableName() string {
	return "myself_view"
}

// Reset 重置gorm会话
func (obj *_MyselfViewMgr) Reset() *_MyselfViewMgr {
	obj.New()
	return obj
}

// Get 获取
func (obj *_MyselfViewMgr) Get() (result MyselfView, err error) {
	err = obj.DB.WithContext(obj.ctx).Model(MyselfView{}).Find(&result).Error

	return
}

// Gets 获取批量结果
func (obj *_MyselfViewMgr) Gets() (results []*MyselfView, err error) {
	err = obj.DB.WithContext(obj.ctx).Model(MyselfView{}).Find(&results).Error

	return
}

////////////////////////////////// gorm replace /////////////////////////////////
func (obj *_MyselfViewMgr) Count(count *int64) (tx *gorm.DB) {
	return obj.DB.WithContext(obj.ctx).Model(MyselfView{}).Count(count)
}

//////////////////////////////////////////////////////////////////////////////////

//////////////////////////option case ////////////////////////////////////////////

// WithID id获取
func (obj *_MyselfViewMgr) WithID(id int) Option {
	return optionFunc(func(o *options) { o.query["id"] = id })
}

// WithCode code获取 股票代码
func (obj *_MyselfViewMgr) WithCode(code string) Option {
	return optionFunc(func(o *options) { o.query["code"] = code })
}

// WithName name获取 股票名字
func (obj *_MyselfViewMgr) WithName(name string) Option {
	return optionFunc(func(o *options) { o.query["name"] = name })
}

// WithDay day获取 入池时间
func (obj *_MyselfViewMgr) WithDay(day datatypes.Date) Option {
	return optionFunc(func(o *options) { o.query["day"] = day })
}

// WithDayStr day_str获取 入池时间
func (obj *_MyselfViewMgr) WithDayStr(dayStr string) Option {
	return optionFunc(func(o *options) { o.query["day_str"] = dayStr })
}

// WithPrice price获取 价格
func (obj *_MyselfViewMgr) WithPrice(price float64) Option {
	return optionFunc(func(o *options) { o.query["price"] = price })
}

// WithNewPrice new_price获取 价格
func (obj *_MyselfViewMgr) WithNewPrice(newPrice float64) Option {
	return optionFunc(func(o *options) { o.query["new_price"] = newPrice })
}

// WithPercent percent获取 百分比
func (obj *_MyselfViewMgr) WithPercent(percent float64) Option {
	return optionFunc(func(o *options) { o.query["percent"] = percent })
}

// WithTurnoverRate turnover_rate获取 换手率
func (obj *_MyselfViewMgr) WithTurnoverRate(turnoverRate float64) Option {
	return optionFunc(func(o *options) { o.query["turnover_rate"] = turnoverRate })
}

// WithNumber number获取 数量
func (obj *_MyselfViewMgr) WithNumber(number int) Option {
	return optionFunc(func(o *options) { o.query["number"] = number })
}

// WithDesc desc获取 描述
func (obj *_MyselfViewMgr) WithDesc(desc string) Option {
	return optionFunc(func(o *options) { o.query["desc"] = desc })
}

// WithCreatedAt created_at获取 创建时间
func (obj *_MyselfViewMgr) WithCreatedAt(createdAt time.Time) Option {
	return optionFunc(func(o *options) { o.query["created_at"] = createdAt })
}

// WithHyName hy_name获取 行业名
func (obj *_MyselfViewMgr) WithHyName(hyName string) Option {
	return optionFunc(func(o *options) { o.query["hy_name"] = hyName })
}

// GetByOption 功能选项模式获取
func (obj *_MyselfViewMgr) GetByOption(opts ...Option) (result MyselfView, err error) {
	options := options{
		query: make(map[string]interface{}, len(opts)),
	}
	for _, o := range opts {
		o.apply(&options)
	}

	err = obj.DB.WithContext(obj.ctx).Model(MyselfView{}).Where(options.query).Find(&result).Error

	return
}

// GetByOptions 批量功能选项模式获取
func (obj *_MyselfViewMgr) GetByOptions(opts ...Option) (results []*MyselfView, err error) {
	options := options{
		query: make(map[string]interface{}, len(opts)),
	}
	for _, o := range opts {
		o.apply(&options)
	}

	err = obj.DB.WithContext(obj.ctx).Model(MyselfView{}).Where(options.query).Find(&results).Error

	return
}

// SelectPage 分页查询
func (obj *_MyselfViewMgr) SelectPage(page IPage, opts ...Option) (resultPage IPage, err error) {
	options := options{
		query: make(map[string]interface{}, len(opts)),
	}
	for _, o := range opts {
		o.apply(&options)
	}
	resultPage = page
	results := make([]MyselfView, 0)
	var count int64 // 统计总的记录数
	query := obj.DB.WithContext(obj.ctx).Model(MyselfView{}).Where(options.query)
	query.Count(&count)
	resultPage.SetTotal(count)
	if len(page.GetOrederItemsString()) > 0 {
		query = query.Order(page.GetOrederItemsString())
	}
	err = query.Limit(int(page.GetSize())).Offset(int(page.Offset())).Find(&results).Error

	resultPage.SetRecords(results)
	return
}

//////////////////////////enume case ////////////////////////////////////////////

// GetFromID 通过id获取内容
func (obj *_MyselfViewMgr) GetFromID(id int) (results []*MyselfView, err error) {
	err = obj.DB.WithContext(obj.ctx).Model(MyselfView{}).Where("`id` = ?", id).Find(&results).Error

	return
}

// GetBatchFromID 批量查找
func (obj *_MyselfViewMgr) GetBatchFromID(ids []int) (results []*MyselfView, err error) {
	err = obj.DB.WithContext(obj.ctx).Model(MyselfView{}).Where("`id` IN (?)", ids).Find(&results).Error

	return
}

// GetFromCode 通过code获取内容 股票代码
func (obj *_MyselfViewMgr) GetFromCode(code string) (results []*MyselfView, err error) {
	err = obj.DB.WithContext(obj.ctx).Model(MyselfView{}).Where("`code` = ?", code).Find(&results).Error

	return
}

// GetBatchFromCode 批量查找 股票代码
func (obj *_MyselfViewMgr) GetBatchFromCode(codes []string) (results []*MyselfView, err error) {
	err = obj.DB.WithContext(obj.ctx).Model(MyselfView{}).Where("`code` IN (?)", codes).Find(&results).Error

	return
}

// GetFromName 通过name获取内容 股票名字
func (obj *_MyselfViewMgr) GetFromName(name string) (results []*MyselfView, err error) {
	err = obj.DB.WithContext(obj.ctx).Model(MyselfView{}).Where("`name` = ?", name).Find(&results).Error

	return
}

// GetBatchFromName 批量查找 股票名字
func (obj *_MyselfViewMgr) GetBatchFromName(names []string) (results []*MyselfView, err error) {
	err = obj.DB.WithContext(obj.ctx).Model(MyselfView{}).Where("`name` IN (?)", names).Find(&results).Error

	return
}

// GetFromDay 通过day获取内容 入池时间
func (obj *_MyselfViewMgr) GetFromDay(day datatypes.Date) (results []*MyselfView, err error) {
	err = obj.DB.WithContext(obj.ctx).Model(MyselfView{}).Where("`day` = ?", day).Find(&results).Error

	return
}

// GetBatchFromDay 批量查找 入池时间
func (obj *_MyselfViewMgr) GetBatchFromDay(days []datatypes.Date) (results []*MyselfView, err error) {
	err = obj.DB.WithContext(obj.ctx).Model(MyselfView{}).Where("`day` IN (?)", days).Find(&results).Error

	return
}

// GetFromDayStr 通过day_str获取内容 入池时间
func (obj *_MyselfViewMgr) GetFromDayStr(dayStr string) (results []*MyselfView, err error) {
	err = obj.DB.WithContext(obj.ctx).Model(MyselfView{}).Where("`day_str` = ?", dayStr).Find(&results).Error

	return
}

// GetBatchFromDayStr 批量查找 入池时间
func (obj *_MyselfViewMgr) GetBatchFromDayStr(dayStrs []string) (results []*MyselfView, err error) {
	err = obj.DB.WithContext(obj.ctx).Model(MyselfView{}).Where("`day_str` IN (?)", dayStrs).Find(&results).Error

	return
}

// GetFromPrice 通过price获取内容 价格
func (obj *_MyselfViewMgr) GetFromPrice(price float64) (results []*MyselfView, err error) {
	err = obj.DB.WithContext(obj.ctx).Model(MyselfView{}).Where("`price` = ?", price).Find(&results).Error

	return
}

// GetBatchFromPrice 批量查找 价格
func (obj *_MyselfViewMgr) GetBatchFromPrice(prices []float64) (results []*MyselfView, err error) {
	err = obj.DB.WithContext(obj.ctx).Model(MyselfView{}).Where("`price` IN (?)", prices).Find(&results).Error

	return
}

// GetFromNewPrice 通过new_price获取内容 价格
func (obj *_MyselfViewMgr) GetFromNewPrice(newPrice float64) (results []*MyselfView, err error) {
	err = obj.DB.WithContext(obj.ctx).Model(MyselfView{}).Where("`new_price` = ?", newPrice).Find(&results).Error

	return
}

// GetBatchFromNewPrice 批量查找 价格
func (obj *_MyselfViewMgr) GetBatchFromNewPrice(newPrices []float64) (results []*MyselfView, err error) {
	err = obj.DB.WithContext(obj.ctx).Model(MyselfView{}).Where("`new_price` IN (?)", newPrices).Find(&results).Error

	return
}

// GetFromPercent 通过percent获取内容 百分比
func (obj *_MyselfViewMgr) GetFromPercent(percent float64) (results []*MyselfView, err error) {
	err = obj.DB.WithContext(obj.ctx).Model(MyselfView{}).Where("`percent` = ?", percent).Find(&results).Error

	return
}

// GetBatchFromPercent 批量查找 百分比
func (obj *_MyselfViewMgr) GetBatchFromPercent(percents []float64) (results []*MyselfView, err error) {
	err = obj.DB.WithContext(obj.ctx).Model(MyselfView{}).Where("`percent` IN (?)", percents).Find(&results).Error

	return
}

// GetFromTurnoverRate 通过turnover_rate获取内容 换手率
func (obj *_MyselfViewMgr) GetFromTurnoverRate(turnoverRate float64) (results []*MyselfView, err error) {
	err = obj.DB.WithContext(obj.ctx).Model(MyselfView{}).Where("`turnover_rate` = ?", turnoverRate).Find(&results).Error

	return
}

// GetBatchFromTurnoverRate 批量查找 换手率
func (obj *_MyselfViewMgr) GetBatchFromTurnoverRate(turnoverRates []float64) (results []*MyselfView, err error) {
	err = obj.DB.WithContext(obj.ctx).Model(MyselfView{}).Where("`turnover_rate` IN (?)", turnoverRates).Find(&results).Error

	return
}

// GetFromNumber 通过number获取内容 数量
func (obj *_MyselfViewMgr) GetFromNumber(number int) (results []*MyselfView, err error) {
	err = obj.DB.WithContext(obj.ctx).Model(MyselfView{}).Where("`number` = ?", number).Find(&results).Error

	return
}

// GetBatchFromNumber 批量查找 数量
func (obj *_MyselfViewMgr) GetBatchFromNumber(numbers []int) (results []*MyselfView, err error) {
	err = obj.DB.WithContext(obj.ctx).Model(MyselfView{}).Where("`number` IN (?)", numbers).Find(&results).Error

	return
}

// GetFromDesc 通过desc获取内容 描述
func (obj *_MyselfViewMgr) GetFromDesc(desc string) (results []*MyselfView, err error) {
	err = obj.DB.WithContext(obj.ctx).Model(MyselfView{}).Where("`desc` = ?", desc).Find(&results).Error

	return
}

// GetBatchFromDesc 批量查找 描述
func (obj *_MyselfViewMgr) GetBatchFromDesc(descs []string) (results []*MyselfView, err error) {
	err = obj.DB.WithContext(obj.ctx).Model(MyselfView{}).Where("`desc` IN (?)", descs).Find(&results).Error

	return
}

// GetFromCreatedAt 通过created_at获取内容 创建时间
func (obj *_MyselfViewMgr) GetFromCreatedAt(createdAt time.Time) (results []*MyselfView, err error) {
	err = obj.DB.WithContext(obj.ctx).Model(MyselfView{}).Where("`created_at` = ?", createdAt).Find(&results).Error

	return
}

// GetBatchFromCreatedAt 批量查找 创建时间
func (obj *_MyselfViewMgr) GetBatchFromCreatedAt(createdAts []time.Time) (results []*MyselfView, err error) {
	err = obj.DB.WithContext(obj.ctx).Model(MyselfView{}).Where("`created_at` IN (?)", createdAts).Find(&results).Error

	return
}

// GetFromHyName 通过hy_name获取内容 行业名
func (obj *_MyselfViewMgr) GetFromHyName(hyName string) (results []*MyselfView, err error) {
	err = obj.DB.WithContext(obj.ctx).Model(MyselfView{}).Where("`hy_name` = ?", hyName).Find(&results).Error

	return
}

// GetBatchFromHyName 批量查找 行业名
func (obj *_MyselfViewMgr) GetBatchFromHyName(hyNames []string) (results []*MyselfView, err error) {
	err = obj.DB.WithContext(obj.ctx).Model(MyselfView{}).Where("`hy_name` IN (?)", hyNames).Find(&results).Error

	return
}

//////////////////////////primary index case ////////////////////////////////////////////
