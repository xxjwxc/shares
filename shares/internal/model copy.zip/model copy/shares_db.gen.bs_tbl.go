package model

import (
	"context"
	"fmt"
	"gorm.io/gorm"
	"time"
)

type _BsTblMgr struct {
	*_BaseMgr
}

// BsTblMgr open func
func BsTblMgr(db *gorm.DB) *_BsTblMgr {
	if db == nil {
		panic(fmt.Errorf("BsTblMgr need init by db"))
	}
	ctx, cancel := context.WithCancel(context.Background())
	return &_BsTblMgr{_BaseMgr: &_BaseMgr{DB: db.Table("bs_tbl"), isRelated: globalIsRelated, ctx: ctx, cancel: cancel, timeout: -1}}
}

// GetTableName get sql table name.获取数据库名字
func (obj *_BsTblMgr) GetTableName() string {
	return "bs_tbl"
}

// Reset 重置gorm会话
func (obj *_BsTblMgr) Reset() *_BsTblMgr {
	obj.New()
	return obj
}

// Get 获取
func (obj *_BsTblMgr) Get() (result BsTbl, err error) {
	err = obj.DB.WithContext(obj.ctx).Model(BsTbl{}).Find(&result).Error

	return
}

// Gets 获取批量结果
func (obj *_BsTblMgr) Gets() (results []*BsTbl, err error) {
	err = obj.DB.WithContext(obj.ctx).Model(BsTbl{}).Find(&results).Error

	return
}

////////////////////////////////// gorm replace /////////////////////////////////
func (obj *_BsTblMgr) Count(count *int64) (tx *gorm.DB) {
	return obj.DB.WithContext(obj.ctx).Model(BsTbl{}).Count(count)
}

//////////////////////////////////////////////////////////////////////////////////

//////////////////////////option case ////////////////////////////////////////////

// WithID id获取
func (obj *_BsTblMgr) WithID(id int) Option {
	return optionFunc(func(o *options) { o.query["id"] = id })
}

// WithCode code获取 股票代码
func (obj *_BsTblMgr) WithCode(code string) Option {
	return optionFunc(func(o *options) { o.query["code"] = code })
}

// WithCreatedBy created_by获取 创建者
func (obj *_BsTblMgr) WithCreatedBy(createdBy string) Option {
	return optionFunc(func(o *options) { o.query["created_by"] = createdBy })
}

// WithCreatedAt created_at获取 创建时间
func (obj *_BsTblMgr) WithCreatedAt(createdAt time.Time) Option {
	return optionFunc(func(o *options) { o.query["created_at"] = createdAt })
}

// GetByOption 功能选项模式获取
func (obj *_BsTblMgr) GetByOption(opts ...Option) (result BsTbl, err error) {
	options := options{
		query: make(map[string]interface{}, len(opts)),
	}
	for _, o := range opts {
		o.apply(&options)
	}

	err = obj.DB.WithContext(obj.ctx).Model(BsTbl{}).Where(options.query).Find(&result).Error

	return
}

// GetByOptions 批量功能选项模式获取
func (obj *_BsTblMgr) GetByOptions(opts ...Option) (results []*BsTbl, err error) {
	options := options{
		query: make(map[string]interface{}, len(opts)),
	}
	for _, o := range opts {
		o.apply(&options)
	}

	err = obj.DB.WithContext(obj.ctx).Model(BsTbl{}).Where(options.query).Find(&results).Error

	return
}

// SelectPage 分页查询
func (obj *_BsTblMgr) SelectPage(page IPage, opts ...Option) (resultPage IPage, err error) {
	options := options{
		query: make(map[string]interface{}, len(opts)),
	}
	for _, o := range opts {
		o.apply(&options)
	}
	resultPage = page
	results := make([]BsTbl, 0)
	var count int64 // 统计总的记录数
	query := obj.DB.WithContext(obj.ctx).Model(BsTbl{}).Where(options.query)
	query.Count(&count)
	resultPage.SetTotal(count)
	if len(page.GetOrederItemsString()) > 0 {
		query = query.Order(page.GetOrederItemsString())
	}
	err = query.Limit(int(page.GetSize())).Offset(int(page.Offset())).Find(&results).Error

	resultPage.SetRecords(results)
	return
}

//////////////////////////enume case ////////////////////////////////////////////

// GetFromID 通过id获取内容
func (obj *_BsTblMgr) GetFromID(id int) (result BsTbl, err error) {
	err = obj.DB.WithContext(obj.ctx).Model(BsTbl{}).Where("`id` = ?", id).Find(&result).Error

	return
}

// GetBatchFromID 批量查找
func (obj *_BsTblMgr) GetBatchFromID(ids []int) (results []*BsTbl, err error) {
	err = obj.DB.WithContext(obj.ctx).Model(BsTbl{}).Where("`id` IN (?)", ids).Find(&results).Error

	return
}

// GetFromCode 通过code获取内容 股票代码
func (obj *_BsTblMgr) GetFromCode(code string) (result BsTbl, err error) {
	err = obj.DB.WithContext(obj.ctx).Model(BsTbl{}).Where("`code` = ?", code).Find(&result).Error

	return
}

// GetBatchFromCode 批量查找 股票代码
func (obj *_BsTblMgr) GetBatchFromCode(codes []string) (results []*BsTbl, err error) {
	err = obj.DB.WithContext(obj.ctx).Model(BsTbl{}).Where("`code` IN (?)", codes).Find(&results).Error

	return
}

// GetFromCreatedBy 通过created_by获取内容 创建者
func (obj *_BsTblMgr) GetFromCreatedBy(createdBy string) (results []*BsTbl, err error) {
	err = obj.DB.WithContext(obj.ctx).Model(BsTbl{}).Where("`created_by` = ?", createdBy).Find(&results).Error

	return
}

// GetBatchFromCreatedBy 批量查找 创建者
func (obj *_BsTblMgr) GetBatchFromCreatedBy(createdBys []string) (results []*BsTbl, err error) {
	err = obj.DB.WithContext(obj.ctx).Model(BsTbl{}).Where("`created_by` IN (?)", createdBys).Find(&results).Error

	return
}

// GetFromCreatedAt 通过created_at获取内容 创建时间
func (obj *_BsTblMgr) GetFromCreatedAt(createdAt time.Time) (results []*BsTbl, err error) {
	err = obj.DB.WithContext(obj.ctx).Model(BsTbl{}).Where("`created_at` = ?", createdAt).Find(&results).Error

	return
}

// GetBatchFromCreatedAt 批量查找 创建时间
func (obj *_BsTblMgr) GetBatchFromCreatedAt(createdAts []time.Time) (results []*BsTbl, err error) {
	err = obj.DB.WithContext(obj.ctx).Model(BsTbl{}).Where("`created_at` IN (?)", createdAts).Find(&results).Error

	return
}

//////////////////////////primary index case ////////////////////////////////////////////

// FetchByPrimaryKey primary or index 获取唯一内容
func (obj *_BsTblMgr) FetchByPrimaryKey(id int) (result BsTbl, err error) {
	err = obj.DB.WithContext(obj.ctx).Model(BsTbl{}).Where("`id` = ?", id).Find(&result).Error

	return
}

// FetchUniqueByCode primary or index 获取唯一内容
func (obj *_BsTblMgr) FetchUniqueByCode(code string) (result BsTbl, err error) {
	err = obj.DB.WithContext(obj.ctx).Model(BsTbl{}).Where("`code` = ?", code).Find(&result).Error

	return
}
